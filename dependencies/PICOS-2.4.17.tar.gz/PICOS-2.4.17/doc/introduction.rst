.. _introduction:

.. include:: ../README.rst
