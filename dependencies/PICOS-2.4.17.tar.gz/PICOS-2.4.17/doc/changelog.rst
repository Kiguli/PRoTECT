.. _changelog:

.. include:: ../CHANGELOG.rst
