Introduction
============

PICOS is a user friendly Python API to several conic and integer programming
solvers, designed to be used by both application developers and researchers as
well as instructors teaching courses on mathematical optimization. It allows you
to enter an optimization problem as a **high level model**, with painless
support for **(complex) vector and matrix variables** and **multidimensional
algebra**. Your model will be transformed to the standard form understood by an
appropriate solver that is available at runtime. This makes your application
**portable** as users have the choice between several commercial and open source
solvers.

Features
--------

PICOS supports the following solvers and problem types. To use a solver, you
need to separately install it along with the Python interface listed here.

.. _Apache-2.0: https://www.apache.org/licenses/LICENSE-2.0
.. _GPL-3: https://www.gnu.org/licenses/gpl-3.0.html
.. _MIT: https://opensource.org/licenses/MIT
.. _ZIB: https://scip.zib.de/academic.txt

.. list-table::
    :header-rows: 1

    * - | Solver
        |
      - | Python
        | interface
      - | `LP <https://en.wikipedia.org/wiki/Linear_programming>`_
        |
      - | `SOCP <https://en.wikipedia.org/wiki/Second-order_cone_programming>`_,
        | `QCQP <https://en.wikipedia.org/wiki/Quadratically_constrained_quadratic_program>`_
      - | `SDP <https://en.wikipedia.org/wiki/Semidefinite_programming>`_
        |
      - | `EXP <https://docs.mosek.com/modeling-cookbook/expo.html>`_
        |
      - | `MIP <https://en.wikipedia.org/wiki/Integer_programming>`_
        |
      - | License
        |
    * - `CPLEX <https://www.ibm.com/analytics/cplex-optimizer>`_
      - included
      - Yes
      - Yes
      -
      -
      - Yes
      - non-free
    * - `CVXOPT <https://cvxopt.org/>`_
      - native
      - Yes
      - Yes
      - Yes
      - `GP <https://en.wikipedia.org/wiki/Geometric_programming>`_
      -
      - `GPL-3`_
    * - `ECOS <https://github.com/embotech/ecos>`_
      - `ecos-python <https://github.com/embotech/ecos-python>`_
      - Yes
      - Yes
      -
      - Yes
      - Yes
      - `GPL-3`_
    * - `GLPK <https://www.gnu.org/software/glpk/>`_
      - `swiglpk <https://github.com/biosustain/swiglpk>`_
      - Yes
      -
      -
      -
      - Yes
      - `GPL-3`_
    * - `Gurobi <http://www.gurobi.com/products/gurobi-optimizer>`_
      - `gurobipy <https://www.gurobi.com>`_
      - Yes
      - Yes
      -
      -
      - Yes
      - non-free
    * - `MOSEK <https://www.mosek.com/>`_
      - included
      - Yes
      - Yes
      - Yes
      -
      - Yes
      - non-free
    * - `OSQP <https://osqp.org>`_
      - native
      - Yes
      - `QP <https://en.wikipedia.org/wiki/Quadratic_programming>`_
      -
      -
      -
      - `Apache-2.0`_
    * - `SCIP <http://scip.zib.de/>`_
      - `PySCIPOpt <https://github.com/SCIP-Interfaces/PySCIPOpt/>`_
      - Yes
      - Yes
      -
      -
      - Yes
      - `ZIB`_/`MIT`_
    * - `SMCP <http://smcp.readthedocs.io/en/latest/>`_
      - native
      -
      -
      - Yes
      -
      -
      - `GPL-3`_

.. rubric:: Example

This is what it looks like to solve a multidimensional mixed integer program
with PICOS:

>>> import picos as pc
>>> P = pc.Problem()
>>> x = pc.IntegerVariable("x", 2)
>>> P += 2*x <= 11
>>> P.maximize = pc.sum(x)
>>> P.solve(solver="glpk")  # Optional: Use GLPK as backend.
<feasible primal solution (claimed optimal) from glpk>
>>> P.value
10.0
>>> print(x)
[ 5.00e+00]
[ 5.00e+00]

You can head to our
`quick examples <https://picos-api.gitlab.io/picos/quick.html>`_ or the
`tutorial <https://picos-api.gitlab.io/picos/tutorial.html>`_ for more.

Installation
------------

As of release 2.2, PICOS requires **Python 3.4** or later.

.. rubric:: Via pip

If you are using `pip <https://pypi.org/project/pip/>`_ you can run
``pip install picos`` to get the latest version.

.. rubric:: Via Anaconda

If you are using `Anaconda <https://anaconda.org/>`_ you can run
``conda install -c picos picos`` to get the latest version.

.. rubric:: Via your system's package manager

.. list-table::
    :header-rows: 1
    :stub-columns: 1

    * - Distribution
      - Latest major version
      - Latest version
    * - Arch Linux
      - `python-picos <https://aur.archlinux.org/packages/python-picos/>`__
      - `python-picos-git <https://aur.archlinux.org/packages/python-picos-git/>`__

If you are packaging PICOS for additional platforms, please let us know.

.. rubric:: From source

The PICOS source code can be found on `GitLab
<https://gitlab.com/picos-api/picos>`_. There are only two dependencies:

- `NumPy <https://numpy.org/>`_
- `CVXOPT`_

Documentation
-------------

The full documentation can be browsed `online
<https://picos-api.gitlab.io/picos/>`__ or downloaded `in PDF form
<https://picos-api.gitlab.io/picos/picos.pdf>`__.

Credits
-------

.. rubric:: Developers

- `Guillaume Sagnol <http://page.math.tu-berlin.de/~sagnol/>`_ has started work
  on PICOS in 2012.
- `Maximilian Stahlberg <https://orcid.org/0000-0002-0190-2693>`_ is extending
  and co-maintaining PICOS since 2017.

.. rubric:: Contributors

For an up-to-date list of all code contributors, please refer to the
`contributors page <https://gitlab.com/picos-api/picos/-/graphs/master>`_.
Should a reference from before 2019 be unclear, see also the `old contributors
page <https://github.com/gsagnol/picos/graphs/contributors>`_ on GitHub.

Citing
------

The preferred way to cite PICOS in your research is our `JOSS paper
<https://joss.theoj.org/papers/10.21105/joss.03915>`_:

.. code-block:: bibtex

  @article{PICOS,
    author  = {Guillaume Sagnol and Maximilian Stahlberg},
    journal = {Journal of Open Source Software},
    title   = {{PICOS}: A {Python} interface to conic optimization solvers},
    year    = {2022},
    issn    = {2475-9066},
    month   = feb,
    number  = {70},
    pages   = {3915},
    volume  = {7},
    doi     = {10.21105/joss.03915},
  }

If citing a specific version of PICOS is necessary, then we offer also `source
deposits on Zenodo <https://doi.org/10.5281/zenodo.6052843>`_.

License
-------

PICOS is free and open source software and available to you under the terms of
the `GNU GPL v3 <https://gitlab.com/picos-api/picos/raw/master/LICENSE.txt>`_.
