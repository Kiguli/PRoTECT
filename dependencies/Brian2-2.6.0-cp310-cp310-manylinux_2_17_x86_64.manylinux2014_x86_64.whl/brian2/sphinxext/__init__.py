"""
Brian-specific extension to the Sphinx documentation generation system.
"""
