double foo(const double x, const double y)
{
    return x + y + 3;
}