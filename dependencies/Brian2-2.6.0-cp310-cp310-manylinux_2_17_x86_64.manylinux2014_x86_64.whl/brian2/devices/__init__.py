"""
Package providing the "devices" infrastructure.
"""

from . import device as device_module
from .device import *
